# DMart Regional Director Assistant

All data is synthetic practice data produced by `scripts/generate_data.py`. It is not DMart's real data.

## Purpose

Kavita Rao believes Pune has the lowest revenue because of stockouts. This repository (1) cleans the store data and tests that premise, (2) specifies a conversational assistant, (3) builds it so every number traces to a data field, and (4) evaluates it and decides whether to release it.

**Result of the premise test:** not supported. Pune ranks 4th of 5 on mean stockout hours (2.32 against 2.74 for all stores; Hyderabad is highest at 3.85). Pune's revenue is 26.14% below the all-store mean, its footfall 25.00% below, and its revenue per footfall only 1.52% below: the gap is a footfall gap.

## Setup and run order (free, offline path)

Python 3.9+, `pandas`, `numpy` and the standard library. Defaults: `LLM_MODE=mock` (rule-based interpreter and fixed templates), `WEATHER_MODE=stub`, local SQLite built in memory from the CSVs. No account or API key.

```
pip install -r requirements.txt
python scripts/generate_data.py      # writes the 3 raw files in data/ (never edited afterwards)
python scripts/clean_data.py         # store_daily_clean.csv, cleaning_log.csv, data_quality_report.md
python scripts/analyze.py            # findings.md, executive_summary.md
python scripts/run_acceptance.py     # 20 cases -> outputs/acceptance_transcript.md, logs/runs.jsonl
python eval/build_golden.py          # golden_set.csv + golden_set_derivation.md (figures from pandas)
python eval/run_eval.py              # eval_results.csv, eval_runs.jsonl, eval_summary.md, docs/release_gate.md
```

Optional and ungraded: a hosted PostgreSQL database, a hosted LLM (key in an untracked `.env`, which `.gitignore` lists), and `WEATHER_MODE=live` (needs `requests`). If you use or commit live weather data: Weather data by Open-Meteo.com https://open-meteo.com/ (non-commercial use, CC BY 4.0). No live data is committed here.

## Layout

```
README.md  .gitignore  requirements.txt
data/      raw store_daily/inventory/feedback CSVs, store_daily_clean.csv
scripts/   generate_data.py clean_data.py analyze.py run_acceptance.py
analysis/  data_quality_report.md cleaning_log.csv findings.md executive_summary.md
docs/      requirement.md data_context.md agent_spec.md release_gate.md
agent/     understand.py fetch.py answer.py run_agent.py
tools/     weather.py
tests/     weather_tool_tests.md
outputs/   acceptance_transcript.md
logs/      runs.jsonl (exactly the 20 acceptance lines)
eval/      golden_set.csv golden_set_derivation.md build_golden.py run_eval.py eval_results.csv eval_runs.jsonl eval_summary.md
```

## Rounding method

Every average is the exact mean rounded half-up to 2 decimals: SQL returns COUNT(metric) and the sum of whole cents (`SUM(CAST(ROUND(metric*100) AS INTEGER))`), and Python divides with the `decimal` module and `ROUND_HALF_UP`.

## Results

20/20 acceptance cases return the required status, intent and content. The golden set has 49 cases (24 fixed plus 25 of my own); see `eval/eval_summary.md` for cost, latency, quality and safety, and `docs/release_gate.md` for the four-condition decision (GO on the measured numbers).

## Known limitations

- The interpreter is rule-based: phrasing outside its closed word lists and date grammar is asked about or refused, never guessed.
- Only one product per question; no fuzzy matching of products.
- Context holds one value per entity; there is no multi-turn reasoning beyond follow-ups that reuse store, metric, date or product.
- Latency and cost are for the offline mode only; a hosted LLM would change both.
- Data is synthetic and 90 days long, so no seasonality or trend claims are supported.
- The live weather branch is read-reviewed code only; it was not run.

## Iteration-2 backlog (prioritised)

1. **Trend questions** (Why-style questions today escalate). *Input:* "How did Pune's revenue move week by week in May?" *Output:* weekly averages with the dates, no causal claim. *Success:* every number matches a SQL weekly average; ungrounded_numbers stays 0; answered in under 150 tokens. *Failure:* fewer than 2 full weeks in range gives Safe Failure; unsupported grouping gives Clarification Needed.
2. **Deeper follow-ups** ("and the week before?", "same for Hyderabad"). *Input:* previous resolved entities plus a relative range. *Output:* the same question with the shifted entity. *Success:* follow-up golden cases pass without any unresolved entity filled wrongly. *Failure:* an ambiguous reference asks which entity; it never guesses.
3. **Hosted database** (PostgreSQL in place of SQLite). *Input:* a connection string in `.env`. *Output:* identical answers from the same parameterised queries. *Success:* the 49-case golden set passes unchanged. *Failure:* connection errors use the existing 3-attempt retry and then Escalated.
4. **Hosted LLM interpreter behind the same understand() contract.** *Input:* the question and context. *Output:* the same entity dictionary. *Success:* the golden set passes at 90% or more with every safety category at 100%. *Failure:* invalid output falls back to the rule-based interpreter.
