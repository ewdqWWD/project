"""Runs the 20 acceptance cases. python scripts/run_acceptance.py"""
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["AGENT_LOG_PATH"] = "logs/runs.jsonl"
os.environ["WEATHER_MODE"] = "stub"
open("logs/runs.jsonl", "w").close()
from agent.run_agent import handle   # noqa: E402

CASES = [
    ("A01", "s1", "What was Pune's revenue on 15 May 2026?", 0), ("A02", "s1", "And the target?", 0),
    ("A03", "s1", "How about Mumbai?", 0), ("A04", "s2", "How is Hyderabad doing?", 0),
    ("A05", "s2", "revenue on 2026-05-15", 0), ("A06", "s3", "What was Hydrabad's turnover yesterday?", 0),
    ("A07", "s4", "Did Pune hit its target on 2026-05-16?", 0), ("A08", "s4", "Did Pune hit its target on 2026-05-20?", 0),
    ("A09", "s4", "Did Mumbai hit its target on 2026-05-21?", 0),
    ("A10", "s5", "Which store had the highest average revenue between 2026-05-01 and 2026-05-31?", 0),
    ("A11", "s5", "Which store had the lowest revenue on 2026-06-10?", 0),
    ("A12", "s6", "Which stores are below the reorder threshold for Amul Milk?", 0),
    ("A13", "s6", "What are customers saying about Hyderabad?", 0),
    ("A14", "s7", "What was Pune's profit margin on 2026-05-15?", 0), ("A15", "s8", "What is the capital of India?", 0),
    ("A16", "s9", "What was Mumbai's revenue on 2026-07-15?", 0), ("A17", "s10", "Why is Pune's revenue so low?", 0),
    ("A18", "s11", "What was Kolkata's revenue on 2026-05-15?", 0),
    ("A19", "s12", "What was Pune's revenue on 15 May 2026?", 2), ("A20", "s13", "What was Pune's revenue on 15 May 2026?", 3),
]
out = ["# Acceptance transcript (20 cases)\n"]
for cid, sid, q, fail in CASES:
    os.environ["SIMULATE_DB_FAILURES"] = str(fail)
    r = handle(q, sid)
    out.append(f"## {cid}\n- session: {sid}\n- question: {q}\n- simulated failures: {fail}\n- status: {r['status']}\n"
               f"- intent: {r['intent']}\n- confidence: {r['confidence']}\n- route: {r['route']}\n- attempts: {r['attempts']}\n"
               f"- answer_text: {r['answer_text']}\n")
os.environ["SIMULATE_DB_FAILURES"] = "0"
Path("outputs").mkdir(exist_ok=True)
Path("outputs/acceptance_transcript.md").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
