"""Part A cleaning. Run from repo root: python scripts/clean_data.py
Reads data/store_daily.csv (never modified); writes data/store_daily_clean.csv,
analysis/cleaning_log.csv and analysis/data_quality_report.md."""
import csv
from decimal import Decimal, ROUND_HALF_UP
import numpy as np
import pandas as pd

def hu2(x):
    return float(Decimal(repr(float(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

def bounds(s):
    s = s.dropna()
    q1, q3 = s.quantile(0.25), s.quantile(0.75)   # linear interpolation (same as describe())
    iqr = q3 - q1
    return q1, q3, q1 - 1.5 * iqr, q3 + 1.5 * iqr

raw = pd.read_csv("data/store_daily.csv")
log = []

# 1. exact duplicates, keep first
n_dup = int(raw.duplicated().sum())
df = raw.drop_duplicates(keep="first").reset_index(drop=True)

# 2. negative footfall -> missing
for i in df.index[df["footfall"] < 0]:
    log.append((df.at[i, "store"], df.at[i, "date"], f"{df.at[i, 'footfall']:g}", "", "negative_to_missing"))
df.loc[df["footfall"] < 0, "footfall"] = np.nan

# 3. per-store IQR cap
bdict, outside = {}, []
for st, g in df.groupby("store"):
    q1, q3, lo, hi = bounds(g["footfall"])
    bdict[st] = (q1, q3, lo, hi)
for st, (q1, q3, lo, hi) in bdict.items():
    idx = df.index[(df["store"] == st) & df["footfall"].notna() & ((df["footfall"] < lo) | (df["footfall"] > hi))]
    for i in idx:
        old = df.at[i, "footfall"]
        new = hu2(hi if old > hi else lo)
        outside.append((st, df.at[i, "date"], old))
        log.append((st, df.at[i, "date"], f"{old:g}", f"{new:.2f}", "iqr_cap"))
        df.at[i, "footfall"] = new

# 4. per-store median imputation
for st, g in df.groupby("store"):
    med = float(g["footfall"].median())
    idx = df.index[(df["store"] == st) & df["footfall"].isna()]
    for i in idx:
        log.append((st, df.at[i, "date"], "", str(med), "median_impute"))
        df.at[i, "footfall"] = med

# 5. features (revenue and other columns untouched)
df["revenue_per_footfall"] = (df["revenue_inr"] / df["footfall"]).round(2)
df["marketing_efficiency"] = (df["revenue_inr"] / df["marketing_spend_inr"]).round(2)
df["achievement_pct"] = (df["revenue_inr"] / df["daily_target_inr"] * 100).round(2)
df["shortfall_inr"] = (df["daily_target_inr"] - df["revenue_inr"]).round(2)
df["weekend_flag"] = np.where(pd.to_datetime(df["date"]).dt.day_of_week >= 5, "Yes", "No")
df["performance_band"] = np.where(df["achievement_pct"] >= 100, "Excellent",
                                  np.where(df["achievement_pct"] >= 75, "Good", "Poor"))
assert len(df) == 450 and df.isna().sum().sum() == 0 and (df["footfall"] >= 0).all()
df.to_csv("data/store_daily_clean.csv", index=False)
with open("analysis/cleaning_log.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["store", "date", "old_footfall", "new_footfall", "rule"])
    for r in log:
        w.writerow(r)

# ---- data quality report (on the RAW file) ----
d2 = raw.drop_duplicates().copy()
d2.loc[d2["footfall"] < 0, "footfall"] = np.nan
L = []
L.append("# Data quality report: data/store_daily.csv (raw)\n")
L.append(f"## Shape\n\n{raw.shape[0]} rows x {raw.shape[1]} columns.\n")
L.append("## Data types and null counts\n\n| column | dtype | nulls |\n|---|---|---|")
for c in raw.columns:
    L.append(f"| {c} | {raw[c].dtype} | {int(raw[c].isna().sum())} |")
L.append(f"\n## Duplicates\n\nExact duplicate rows: **{n_dup}** (appended at the end of the file).\n")
L.append(f"## Footfall range (raw)\n\nMinimum **{raw['footfall'].min():.0f}**, maximum **{raw['footfall'].max():.0f}** "
         f"({int(raw['footfall'].isna().sum())} missing values, {int((raw['footfall']<0).sum())} negative).\n")
L.append("## Per-store IQR bounds of footfall\n\nComputed after removing exact duplicates and treating negative footfall as missing, "
         "on non-missing values only, percentiles by linear interpolation.\n")
L.append("| store | Q1 | Q3 | lower bound | upper bound |\n|---|---|---|---|---|")
for st in sorted(bdict):
    q1, q3, lo, hi = bdict[st]
    L.append(f"| {st} | {q1:.2f} | {q3:.2f} | {lo:.2f} | {hi:.3f} |")
L.append("\nRows outside the bounds:\n\n| store | date | footfall | bound exceeded |\n|---|---|---|---|")
for st, d, v in outside:
    L.append(f"| {st} | {d} | {v:.0f} | {'upper' if v > bdict[st][3] else 'lower'} |")
L.append("""
## Decisions

**Duplicates.** Removed the 3 exact duplicate rows, keeping the first occurrence. A repeated row would count one store-day twice and inflate means and totals; the rows are byte-identical, so no information is lost. The raw file still contains all 3.

**Negative values.** Footfall of -150 (Hyderabad, 2026-04-21) is physically impossible, so I set it to missing instead of keeping or flipping the sign. I did not use zero, because zero would claim an empty store on a day with INR revenue. It then went through the missing-value rule. The raw file still contains -150.

**Extreme values.** Footfall 9800 (Ahmedabad) and 6100 (Mumbai) are far above the per-store upper bound but possible, so I treated them as genuine extreme busy days and capped them at the store's upper bound (2281.38 and 2986.00) instead of deleting the rows. Deleting would throw away valid revenue for that day; capping keeps the row and limits the leverage on correlations. Per-store bounds are used because stores differ in size (Pune's normal range would flag nothing at Mumbai's scale). The raw file still contains 9800 and 6100.

**Missing values.** 4 missing footfall values plus the 1 negative-turned-missing were filled with that store's median footfall (never zero, never the all-store median or mean). The median is robust to the extremes found above, and per-store filling respects the large size differences between stores. 5 values were imputed. The raw file still contains the 4 blanks.

Revenue and every other column are untouched. Every change is listed in analysis/cleaning_log.csv.
""")
open("analysis/data_quality_report.md", "w").write("\n".join(L))
print("rows", len(df), "log", len(log), [r[4] for r in log])
