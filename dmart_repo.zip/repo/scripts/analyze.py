"""Part A analysis. Run: python scripts/analyze.py  (reads cleaned file; writes findings.md and executive_summary.md)"""
import numpy as np
import pandas as pd

df = pd.read_csv("data/store_daily_clean.csv")
raw = pd.read_csv("data/store_daily.csv").drop_duplicates()
ORDER = ["Mumbai", "Pune", "Hyderabad", "Bengaluru", "Ahmedabad"]

def stats(g):
    return dict(rev=g.revenue_inr.mean(), ff=g.footfall.mean(), so=g.stockout_hours.mean(),
                rpf=g.revenue_inr.sum() / g.footfall.sum(), ach=g.achievement_pct.mean(),
                poor=int((g.performance_band == "Poor").sum()))
S = {s: stats(df[df.store == s]) for s in sorted(ORDER)}
ALL = stats(df)
def r(x): return f"{x:.2f}"

rank = sorted(S, key=lambda s: -S[s]["so"])
pune_rank = rank.index("Pune") + 1
corr = lambda a, b: float(np.corrcoef(a, b)[0, 1])
P = df[df.store == "Pune"]
rr = raw.dropna(subset=["footfall"])
c = dict(all_so=corr(df.revenue_inr, df.stockout_hours), all_ff=corr(df.revenue_inr, df.footfall),
         p_so=corr(P.revenue_inr, P.stockout_hours), p_ff=corr(P.revenue_inr, P.footfall),
         raw_ff=corr(rr.revenue_inr, rr.footfall))
pct = lambda a, b: (a / b - 1) * 100
d_rev, d_ff, d_rpf = pct(S["Pune"]["rev"], ALL["rev"]), pct(S["Pune"]["ff"], ALL["ff"]), pct(S["Pune"]["rpf"], ALL["rpf"])

F = ["# Findings (from data/store_daily_clean.csv)\n", "## Store table\n",
     "| Store | Mean daily revenue (INR) | Mean footfall | Mean stockout hours | Revenue per footfall | Mean achievement_pct | Poor days |",
     "|---|---|---|---|---|---|---|"]
for s, v in list(S.items()) + [("All stores", ALL)]:
    F.append(f"| {s} | {r(v['rev'])} | {r(v['ff'])} | {r(v['so'])} | {r(v['rpf'])} | {r(v['ach'])} | {v['poor']} |")
F += ["\n(All stores = all 450 rows pooled; revenue per footfall = total revenue / total footfall.)\n",
      "## Premise test: \"Pune is lowest because of stockouts\"\n",
      "Ranking of stores by mean stockout hours (most first):\n"]
F += [f"{i+1}. {s}: {r(S[s]['so'])}" for i, s in enumerate(rank)]
F.append(f"\nDoes Pune have more stockout hours than the other stores? **No.** Pune ranks {pune_rank}th of 5 "
         f"({r(S['Pune']['so'])} hours against an all-store mean of {r(ALL['so'])}); {rank[0]} is highest ({r(S[rank[0]]['so'])}). "
         "The premise \"Pune has the most stockouts\" is **not supported**.\n")
F += ["## Correlations (Pearson)\n", "| pair | rows | r |", "|---|---|---|",
      f"| revenue_inr vs stockout_hours | all 450 | {c['all_so']:.3f} |",
      f"| revenue_inr vs footfall | all 450 | {c['all_ff']:.3f} |",
      f"| revenue_inr vs stockout_hours | Pune only | {c['p_so']:.3f} |",
      f"| revenue_inr vs footfall | Pune only | {c['p_ff']:.3f} |",
      f"| revenue_inr vs footfall, BEFORE cleaning (deduplicated raw, non-missing footfall, negative and extreme values kept) | {len(rr)} | {c['raw_ff']:.3f} |",
      f"\nCleaning lifts the revenue-footfall correlation from {c['raw_ff']:.3f} to {c['all_ff']:.3f}: the -150, 9800 and 6100 values were distorting it.",
      "\nCorrelation does not establish causation: a negative revenue-stockout correlation shows the two move together, not that one causes the other.\n",
      "## Facts\n",
      f"- Pune mean daily revenue is INR {r(S['Pune']['rev'])} against an all-store INR {r(ALL['rev'])} ({d_rev:.2f}%).",
      f"- Pune mean footfall is {r(S['Pune']['ff'])} against {r(ALL['ff'])} ({d_ff:.2f}%).",
      f"- Pune revenue per footfall is {r(S['Pune']['rpf'])} against {r(ALL['rpf'])} ({d_rpf:.2f}%).",
      f"- Pune mean stockout hours are {r(S['Pune']['so'])}, 4th of 5; Hyderabad has {r(S['Hyderabad']['so'])}.",
      f"- Pune has {S['Pune']['poor']} Poor days of 90; the other four stores have {ALL['poor']-S['Pune']['poor']} combined.",
      "\n## Insights\n",
      f"- Pune's revenue gap ({d_rev:.2f}%) is almost entirely a footfall gap ({d_ff:.2f}%); revenue per visitor is only {abs(d_rpf):.2f}% lower, so each visitor buys about as much as elsewhere.",
      f"- Stockouts are not Pune's distinguishing problem: Hyderabad has {r(S['Hyderabad']['so'])} stockout hours but achieves {r(S['Hyderabad']['ach'])}% of target against Pune's {r(S['Pune']['ach'])}%.",
      f"- Within Pune the revenue-stockout correlation ({c['p_so']:.3f}) is weaker than revenue-footfall ({c['p_ff']:.3f}), so footfall explains more day-to-day revenue variation.",
      "\n## Hypotheses (unconfirmed)\n",
      "- (Unconfirmed) Pune's catchment or store format produces structurally lower footfall. Data needed: catchment population, store floor area, competitor locations.",
      "- (Unconfirmed) Pune's marketing mix is attracting fewer visits per rupee. Data needed: channel-level campaign spend and hourly or daily footfall by source.",
      "- (Unconfirmed) Stockouts cost Pune some sales on the days they happen. Data needed: SKU-level stockout and lost-sales data."]
open("analysis/findings.md", "w").write("\n".join(F) + "\n")

E = f"""# Executive Summary

**Dataset:** DMart synthetic practice data, store_daily_clean (450 rows, 5 stores). **Period:** 2026-04-01 to 2026-06-29. **Author:** Shubhham.

**Headline:** Pune's low revenue is a footfall gap, not a stockout gap. The stockout programme premise is not supported.

**Magnitude:** Pune's mean daily revenue (INR {r(S['Pune']['rev'])}) is {abs(d_rev):.2f}% below the all-store mean (INR {r(ALL['rev'])}). Its footfall ({r(S['Pune']['ff'])}) is {abs(d_ff):.2f}% below the all-store mean ({r(ALL['ff'])}). Revenue per footfall is only {abs(d_rpf):.2f}% below ({r(S['Pune']['rpf'])} against {r(ALL['rpf'])}).

**Driver and non-driver:** Footfall drives the gap. Stockouts do not: Pune ranks {pune_rank}th of 5 on stockout hours ({r(S['Pune']['so'])} against {r(ALL['so'])}); Hyderabad is highest ({r(S['Hyderabad']['so'])}).

**Supporting facts:**
- Pune is Poor (below 75% of target) on {S['Pune']['poor']} of 90 days.
- Revenue-footfall correlation in Pune is {c['p_ff']:.3f}; revenue-stockout is {c['p_so']:.3f}.
- Correlation is not causation.

**Open hypotheses (unconfirmed):** smaller catchment (needs catchment and competitor data); weaker marketing yield (needs channel-level campaign data).

**Recommendation:** The Regional Operations Director should pause the Pune stock-availability funding and commission a footfall study (catchment, competitors, campaign yield) within 30 days.
"""
words = len(E.split())
assert words <= 250, words
open("analysis/executive_summary.md", "w").write(E)
print("exec words", words); print(open("analysis/findings.md").read()[:1800]); print(c, d_rev, d_ff, d_rpf)
