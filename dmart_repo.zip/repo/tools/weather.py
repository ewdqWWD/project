"""Weather tool. get_weather(city, date) -> dict. WEATHER_MODE=stub (default) | live."""
import os
import re
import datetime as dt

COORDS = {"Mumbai": (19.0760, 72.8777), "Pune": (18.5204, 73.8567), "Hyderabad": (17.3850, 78.4867),
          "Bengaluru": (12.9716, 77.5946), "Ahmedabad": (23.0225, 72.5714)}
LIVE_URL = "https://archive-api.open-meteo.com/v1/archive"   # endpoint string only; not opened by the grader


def _valid_iso(s):
    if not isinstance(s, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return None
    try:
        return dt.date.fromisoformat(s)
    except ValueError:
        return None


def _stub(city, d):
    doy, n = d.timetuple().tm_yday, len(city)
    return {"ok": True, "city": city, "date": d.isoformat(), "mode": "stub",
            "temperature_c": 20 + (n + doy) % 15, "humidity_pct": 40 + (3 * n + doy) % 50,
            "wind_kmh": 5 + doy % 10, "rain_mm": 6.5 if doy % 4 == 0 else 0.0}


def _live(city, d):
    try:
        import requests
        lat, lon = COORDS[city]
        params = {"latitude": lat, "longitude": lon, "start_date": d.isoformat(), "end_date": d.isoformat(),
                  "timezone": "Asia/Kolkata",
                  "daily": "temperature_2m_mean,relative_humidity_2m_mean,wind_speed_10m_max,precipitation_sum"}
        resp = requests.get(LIVE_URL, params=params, timeout=10)
        if resp.status_code != 200:
            return {"ok": False, "error": f"weather service returned status {resp.status_code}"}
        daily = resp.json()["daily"]
        return {"ok": True, "city": city, "date": d.isoformat(), "mode": "live",
                "temperature_c": daily["temperature_2m_mean"][0], "humidity_pct": daily["relative_humidity_2m_mean"][0],
                "wind_kmh": daily["wind_speed_10m_max"][0], "rain_mm": daily["precipitation_sum"][0]}
    except Exception as e:   # network error, timeout, bad JSON, missing keys: never crash the agent
        return {"ok": False, "error": f"live weather failed: {type(e).__name__}"}


def get_weather(city, date):
    canon = {c.lower(): c for c in COORDS}
    name = canon.get(city.strip().lower()) if isinstance(city, str) else None
    if name is None:
        return {"ok": False, "error": f"unsupported city: {city}"}
    d = _valid_iso(date)
    if d is None:
        return {"ok": False, "error": f"invalid date: {date}"}
    if os.environ.get("WEATHER_MODE", "stub").lower() == "live":
        return _live(name, d)
    return _stub(name, d)
