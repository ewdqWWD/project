# Golden-set derivation (own cases)

Figures below were computed with pandas on data/store_daily_clean.csv, data/inventory.csv and data/feedback.csv (mean rounded half-up to 2 decimals), independently of the agent. Cases: G01, G02 (single values), G18 (range mean), G19 (ranking), G20 (feedback), G21 (inventory), G23 (target check), G25 (top store).

- `df[(df.store=='Bengaluru')&(df.date=='2026-05-15')].revenue_inr.iloc[0]` = **970774.76** 
- `df[(df.store=='Mumbai')&(df.date=='2026-05-15')].revenue_inr.iloc[0]` = **1093374.78** 
- `df[(df.store=='Pune')&(df.date>='2026-05-01')&(df.date<='2026-05-07')].footfall.mean()` = **1508.29** 
- `df[(df.date>='2026-05-01')&(df.date<='2026-05-31')].groupby('store').footfall.mean().round(2).sort_values(ascending=False)` = **Mumbai 2388.39; Hyderabad 2228.65; Bengaluru 2066.90; Ahmedabad 1947.01; Pune 1534.24**
- `fb[fb.store=='Pune']`: `.rating.mean()` = **3.71**, `.rating.notna().sum()` = **38**, `len` = **40**, most frequent theme = **Pricing**
- `inv[(inv['product']=='Detergent Powder 1kg')&(inv.stock_units<inv.reorder_threshold)]` = **Ahmedabad 41 units against threshold 108**
- Mumbai 2026-05-16 row: revenue 1176974.96, target 1050000.00, achievement 112.09, band Excellent
- `df[df.date=='2026-05-15'].groupby('store').revenue_inr.mean().round(2).idxmax()` = **Mumbai 1093374.78**
