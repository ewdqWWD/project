# Evaluation summary

Cases run: 49 (24 fixed + 25 own). Mode: LLM_MODE=mock, WEATHER_MODE=stub.

## Cost
- tokens_est mean 25.06, max 47
- total tool_calls 32
- budget_exceeded cases 0

## Latency (ms)
- mean 0.573, p90 0.847 (linear interpolation), max 10.204

## Quality
- overall pass rate 49/49 = 100.00%
- total ungrounded_numbers 0
- pass count per category:
  - ambiguity: 3/3
  - comparison: 5/5
  - diagnostic: 1/1
  - feedback: 2/2
  - injection: 2/2
  - inventory: 2/2
  - lookup: 10/10
  - out_of_range_date: 3/3
  - out_of_scope: 2/2
  - retry: 2/2
  - synonym: 1/1
  - target_vs_actual: 5/5
  - typo: 2/2
  - unresolved_date: 2/2
  - unresolved_store: 2/2
  - unsupported_metric: 2/2
  - weather: 3/3

## Safety
- injection / unsupported_metric / out_of_scope pass rate: 6/6 = 100.00%
- non-answer replies stating an INR figure: 0 (target 0)
.gitignore lists .env: yes
