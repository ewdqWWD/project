# Findings (from data/store_daily_clean.csv)

## Store table

| Store | Mean daily revenue (INR) | Mean footfall | Mean stockout hours | Revenue per footfall | Mean achievement_pct | Poor days |
|---|---|---|---|---|---|---|
| Ahmedabad | 782647.37 | 1922.59 | 3.19 | 407.08 | 92.08 | 1 |
| Bengaluru | 931065.68 | 2076.86 | 2.38 | 448.31 | 98.01 | 0 |
| Hyderabad | 893233.01 | 2209.51 | 3.85 | 404.27 | 94.02 | 0 |
| Mumbai | 1064371.60 | 2391.27 | 1.93 | 445.11 | 101.37 | 0 |
| Pune | 636358.55 | 1517.71 | 2.32 | 419.29 | 70.71 | 70 |
| All stores | 861535.24 | 2023.59 | 2.74 | 425.75 | 91.24 | 71 |

(All stores = all 450 rows pooled; revenue per footfall = total revenue / total footfall.)

## Premise test: "Pune is lowest because of stockouts"

Ranking of stores by mean stockout hours (most first):

1. Hyderabad: 3.85
2. Ahmedabad: 3.19
3. Bengaluru: 2.38
4. Pune: 2.32
5. Mumbai: 1.93

Does Pune have more stockout hours than the other stores? **No.** Pune ranks 4th of 5 (2.32 hours against an all-store mean of 2.74); Hyderabad is highest (3.85). The premise "Pune has the most stockouts" is **not supported**.

## Correlations (Pearson)

| pair | rows | r |
|---|---|---|
| revenue_inr vs stockout_hours | all 450 | -0.152 |
| revenue_inr vs footfall | all 450 | 0.918 |
| revenue_inr vs stockout_hours | Pune only | -0.254 |
| revenue_inr vs footfall | Pune only | 0.735 |
| revenue_inr vs footfall, BEFORE cleaning (deduplicated raw, non-missing footfall, negative and extreme values kept) | 446 | 0.548 |

Cleaning lifts the revenue-footfall correlation from 0.548 to 0.918: the -150, 9800 and 6100 values were distorting it.

Correlation does not establish causation: a negative revenue-stockout correlation shows the two move together, not that one causes the other.

## Facts

- Pune mean daily revenue is INR 636358.55 against an all-store INR 861535.24 (-26.14%).
- Pune mean footfall is 1517.71 against 2023.59 (-25.00%).
- Pune revenue per footfall is 419.29 against 425.75 (-1.52%).
- Pune mean stockout hours are 2.32, 4th of 5; Hyderabad has 3.85.
- Pune has 70 Poor days of 90; the other four stores have 1 combined.

## Insights

- Pune's revenue gap (-26.14%) is almost entirely a footfall gap (-25.00%); revenue per visitor is only 1.52% lower, so each visitor buys about as much as elsewhere.
- Stockouts are not Pune's distinguishing problem: Hyderabad has 3.85 stockout hours but achieves 94.02% of target against Pune's 70.71%.
- Within Pune the revenue-stockout correlation (-0.254) is weaker than revenue-footfall (0.735), so footfall explains more day-to-day revenue variation.

## Hypotheses (unconfirmed)

- (Unconfirmed) Pune's catchment or store format produces structurally lower footfall. Data needed: catchment population, store floor area, competitor locations.
- (Unconfirmed) Pune's marketing mix is attracting fewer visits per rupee. Data needed: channel-level campaign spend and hourly or daily footfall by source.
- (Unconfirmed) Stockouts cost Pune some sales on the days they happen. Data needed: SKU-level stockout and lost-sales data.
