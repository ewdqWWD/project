# Executive Summary

**Dataset:** DMart synthetic practice data, store_daily_clean (450 rows, 5 stores). **Period:** 2026-04-01 to 2026-06-29. **Author:** Shubhham.

**Headline:** Pune's low revenue is a footfall gap, not a stockout gap. The stockout programme premise is not supported.

**Magnitude:** Pune's mean daily revenue (INR 636358.55) is 26.14% below the all-store mean (INR 861535.24). Its footfall (1517.71) is 25.00% below the all-store mean (2023.59). Revenue per footfall is only 1.52% below (419.29 against 425.75).

**Driver and non-driver:** Footfall drives the gap. Stockouts do not: Pune ranks 4th of 5 on stockout hours (2.32 against 2.74); Hyderabad is highest (3.85).

**Supporting facts:**
- Pune is Poor (below 75% of target) on 70 of 90 days.
- Revenue-footfall correlation in Pune is 0.735; revenue-stockout is -0.254.
- Correlation is not causation.

**Open hypotheses (unconfirmed):** smaller catchment (needs catchment and competitor data); weaker marketing yield (needs channel-level campaign data).

**Recommendation:** The Regional Operations Director should pause the Pune stock-availability funding and commission a footfall study (catchment, competitors, campaign yield) within 30 days.
