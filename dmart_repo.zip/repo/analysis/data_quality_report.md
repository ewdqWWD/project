# Data quality report: data/store_daily.csv (raw)

## Shape

453 rows x 9 columns.

## Data types and null counts

| column | dtype | nulls |
|---|---|---|
| date | str | 0 |
| store_id | str | 0 |
| store | str | 0 |
| footfall | float64 | 4 |
| revenue_inr | float64 | 0 |
| daily_target_inr | int64 | 0 |
| marketing_spend_inr | int64 | 0 |
| stockout_hours | float64 | 0 |
| discount_pct | float64 | 0 |

## Duplicates

Exact duplicate rows: **3** (appended at the end of the file).

## Footfall range (raw)

Minimum **-150**, maximum **9800** (4 missing values, 1 negative).

## Per-store IQR bounds of footfall

Computed after removing exact duplicates and treating negative footfall as missing, on non-missing values only, percentiles by linear interpolation.

| store | Q1 | Q3 | lower bound | upper bound |
|---|---|---|---|---|
| Ahmedabad | 1844.50 | 2019.25 | 1582.38 | 2281.375 |
| Bengaluru | 1952.00 | 2211.00 | 1563.50 | 2599.500 |
| Hyderabad | 2053.00 | 2356.00 | 1598.50 | 2810.500 |
| Mumbai | 2246.00 | 2542.00 | 1802.00 | 2986.000 |
| Pune | 1434.00 | 1593.50 | 1194.75 | 1832.750 |

Rows outside the bounds:

| store | date | footfall | bound exceeded |
|---|---|---|---|
| Ahmedabad | 2026-05-26 | 9800 | upper |
| Mumbai | 2026-04-09 | 6100 | upper |

## Decisions

**Duplicates.** Removed the 3 exact duplicate rows, keeping the first occurrence. A repeated row would count one store-day twice and inflate means and totals; the rows are byte-identical, so no information is lost. The raw file still contains all 3.

**Negative values.** Footfall of -150 (Hyderabad, 2026-04-21) is physically impossible, so I set it to missing instead of keeping or flipping the sign. I did not use zero, because zero would claim an empty store on a day with INR revenue. It then went through the missing-value rule. The raw file still contains -150.

**Extreme values.** Footfall 9800 (Ahmedabad) and 6100 (Mumbai) are far above the per-store upper bound but possible, so I treated them as genuine extreme busy days and capped them at the store's upper bound (2281.38 and 2986.00) instead of deleting the rows. Deleting would throw away valid revenue for that day; capping keeps the row and limits the leverage on correlations. Per-store bounds are used because stores differ in size (Pune's normal range would flag nothing at Mumbai's scale). The raw file still contains 9800 and 6100.

**Missing values.** 4 missing footfall values plus the 1 negative-turned-missing were filled with that store's median footfall (never zero, never the all-store median or mean). The median is robust to the extremes found above, and per-store filling respects the large size differences between stores. 5 values were imputed. The raw file still contains the 4 blanks.

Revenue and every other column are untouched. Every change is listed in analysis/cleaning_log.csv.
