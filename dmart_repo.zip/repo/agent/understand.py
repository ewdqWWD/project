"""Rule-based interpreter: understand(question, context) -> dict. Deterministic, no language model."""
import re
import difflib
import datetime as dt

STORES = ["Mumbai", "Pune", "Hyderabad", "Bengaluru", "Ahmedabad"]
EXACT = {s.lower(): s for s in STORES}
EXACT["bangalore"] = "Bengaluru"           # explicit alias, confidence 1.0
AS_OF_DATE = dt.date(2026, 6, 30)
DATA_START, DATA_END = "2026-04-01", "2026-06-29"
THRESHOLD = 0.7
PRODUCTS = [("P01", "Amul Milk 1L"), ("P02", "Toor Dal 1kg"), ("P03", "Basmati Rice 5kg"),
            ("P04", "Sunflower Oil 1L"), ("P05", "Iodised Salt 1kg"), ("P06", "Instant Noodles 70g"),
            ("P07", "Glucose Biscuits 200g"), ("P08", "Detergent Powder 1kg")]
MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august",
          "september", "october", "november", "december"]
WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
MRX = "|".join(MONTHS)


def forms(ws):
    out = set()
    for w in ws:
        out |= {w, w + "s", w + "es"}
    return out


METRIC_WORDS = {"revenue": "revenue_inr", "sales": "revenue_inr", "sale": "revenue_inr",
                "turnover": "revenue_inr", "earnings": "revenue_inr", "earning": "revenue_inr",
                "target": "daily_target_inr", "footfall": "footfall", "visitors": "footfall", "visitor": "footfall",
                "stockout": "stockout_hours", "discount": "discount_pct"}
METRIC_WORDS.update({k + "s": v for k, v in list(METRIC_WORDS.items()) if not k.endswith("s")})
OVERRIDE = forms(["ignore", "disregard", "override", "bypass", "forget", "send", "email", "whatsapp",
                  "purchase", "buy", "restock"])
UNSUPPORTED = forms(["profit", "margin", "marketing", "cost", "expense", "shortfall", "efficiency", "weekend"])
DIAGNOSTIC = forms(["why", "trend", "reason", "because", "cause"])
INVENTORY_W = forms(["reorder", "inventory"])
FEEDBACK_W = forms(["feedback", "review", "rating", "theme"])
TARGET_W = forms(["target"])
TARGET_VERBS = {"hit", "hits", "hitting", "met", "meet", "meets", "meeting", "miss", "misses", "missed", "missing",
                "beat", "beats", "beating", "exceed", "exceeds", "exceeded", "achieve", "achieves", "achieved",
                "reach", "reaches", "reached", "below", "above", "against", "versus"}
COMPARE_W = {"which", "highest", "lowest", "best", "worst"}
WEATHER_W = forms(["weather", "rain", "temperature", "humidity", "hot", "cold"])
BRANDS = {"dmart", "avenue", "supermarts", "kavita", "rao", "meteo", "github", "python", "sqlite", "postgresql", "markdown"}
STOP = {"hello", "thanks", "thank", "kindly", "please", "display", "compare", "which", "what", "whats", "how", "why",
        "did", "and", "show", "check", "report", "where", "would", "could", "can", "will", "give", "tell", "list"}
PREPS = {"in", "on", "of", "during", "since", "for", "from", "until", "till", "by", "to", "through", "throughout",
         "before", "after", "within", "over"}
KEYWORDS = set()
for grp in (METRIC_WORDS.keys(), OVERRIDE, UNSUPPORTED, DIAGNOSTIC, INVENTORY_W, FEEDBACK_W, TARGET_W, TARGET_VERBS,
            COMPARE_W, WEATHER_W, MONTHS, WEEKDAYS):
    KEYWORDS |= set(grp)
KEYWORDS |= forms(["store", "hour", "unit", "threshold", "level", "point", "customer", "say", "saying", "says", "order",
                   "reorder", "achievement", "performance", "band", "footfall", "daily", "weekly", "monthly", "quarterly",
                   "yearly", "annual", "average", "between", "yesterday", "today", "tomorrow", "week", "month", "quarter",
                   "year", "past", "previous", "ago", "recent", "latest", "now", "lately", "morning", "last", "next",
                   "short", "fall", "per", "stock", "total", "price", "daily", "weekday"])
KEYWORDS |= {"yesterday", "between", "saying", "says", "customers", "achievement", "performance"}

ISO_RX = re.compile(r"(?<![\w-])(\d{4})-(\d{2})-(\d{2})(?![\w-])")
DMY_RX = re.compile(rf"(?<![\w-])(\d{{1,2}})\s+({MRX})\s+(\d{{4}})(?![\w-])", re.I)
DATE_ALT = rf"(?:\d{{4}}-\d{{2}}-\d{{2}}|\d{{1,2}}\s+(?:{MRX})\s+\d{{4}})"
BETWEEN_RX = re.compile(rf"(?<![\w-])between\s+({DATE_ALT})\s+and\s+({DATE_ALT})(?![\w-])", re.I)
BAD_PATTERNS = [
    r"\d{4}-\d{1,2}-\d{1,2}", r"\d{4}-w\d{1,2}(?:-\d)?", r"(?<!\d)\d{8}(?!\d)", r"(?<!\d)(?:19|20)\d{2}(?!\d)",
    r"\b\d{1,2}(?:st|nd|rd|th)\b",
    rf"\b\d{{1,2}}\s+(?:{MRX}|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\b",
    r"\b(?:jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\b\.?",
    r"\b(?:january|february|april|june|july|august|september|october|november|december)\b",
    r"\b(?:today|tomorrow|tonight|weeks?|months?|quarters?|years?|ytd|mtd|qtd|fy\s?\d*|q[1-4]|past|previous|ago|"
    r"recent|recently|latest|now|lately|morning|afternoon|evening|last|next|eod|eow|eom)\b",
]


def _to_date(txt):
    t = txt.strip()
    try:
        m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", t)
        if m:
            return dt.date(int(m[1]), int(m[2]), int(m[3]))
        m = re.fullmatch(r"(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})", t)
        if m:
            return dt.date(int(m[3]), MONTHS.index(m[2].lower()) + 1, int(m[1]))
    except ValueError:
        return None
    return None


def parse_dates(q):
    """Closed grammar: ISO, D Month YYYY, yesterday, between <date> and <date>. Anything else date-like is unresolved."""
    s, unresolved, mentioned, rng, singles = q, False, False, None, []
    m = BETWEEN_RX.search(s)
    if m:
        mentioned = True
        a, b = _to_date(m.group(1)), _to_date(m.group(2))
        if a is None or b is None or a > b:
            unresolved = True
        else:
            rng = (a, b)
        s = s[:m.start()] + " " + s[m.end():]
    for rx in (ISO_RX, DMY_RX):
        for mm in rx.finditer(s):
            mentioned = True
            d = _to_date(mm.group(0))
            if d is None:
                unresolved = True
            else:
                singles.append(d)
        s = rx.sub(" ", s)
    for _ in re.finditer(r"\byesterday(?:'s)?\b", s, re.I):
        mentioned = True
        singles.append(AS_OF_DATE - dt.timedelta(days=1))
    s = re.sub(r"\byesterday(?:'s)?\b", " ", s, flags=re.I)
    sl = re.sub(r"\bper\s+(?:day|week|month|year)s?\b", " ", s.lower())
    for p in BAD_PATTERNS:
        if re.search(p, sl):
            mentioned = unresolved = True
    for mm in re.finditer(r"\b(may|march)\b", s, re.I):
        w = mm.group(1)
        prev = re.findall(r"[A-Za-z]+", s[:mm.start()])[-1:]
        nxt = re.findall(r"[A-Za-z]+", s[mm.end():])[:1]
        if w.lower() == "may" and w[0].isupper():
            if nxt and nxt[0].lower() in {"i", "we", "you", "be"}:
                continue
            counts = True
        elif w[0].isupper():
            counts = True
        else:
            counts = bool(prev) and prev[0].lower() in PREPS
        if counts:
            mentioned = unresolved = True
    wd_s = re.findall(r"\b(" + "|".join(WEEKDAYS) + r")\b", sl)
    wd_p = re.findall(r"\b(?:" + "|".join(WEEKDAYS) + r")s\b|\bweekdays?\b", sl)
    if wd_s or wd_p:
        mentioned = True
    if wd_s:
        if len(singles) == 1 and rng is None:
            if any(singles[0].weekday() != WEEKDAYS.index(w) for w in wd_s):
                unresolved = True
        else:
            unresolved = True
    if wd_p and rng is None:
        unresolved = True
    if len(singles) >= 2 or (rng and singles):
        unresolved = True
    if unresolved:
        return dict(status="unresolved", mentioned=True)
    if rng:
        return dict(status="valid", mentioned=True, start=rng[0].isoformat(), end=rng[1].isoformat(), is_range=True)
    if singles:
        d = singles[0].isoformat()
        return dict(status="valid", mentioned=True, start=d, end=d, is_range=False)
    return dict(status="none", mentioned=mentioned)


def find_product(q):
    masked = q
    found = None
    for pid, name in PRODUCTS:
        base, size = name.rsplit(" ", 1)
        rx = re.compile(rf"(?<![\w]){re.escape(base)}(?:\s*{re.escape(size)})?(?![\w])", re.I)
        m = rx.search(masked)
        if m:
            found = found or name
            masked = rx.sub(" ", masked)
    return found, masked


def _tokens(q):
    return [(m.group(0), m.start()) for m in re.finditer(r"[A-Za-z]+(?:'s)?", q)]


def understand(question, context=None):
    ctx = dict(context or {})
    q = question.replace("\u2019", "'").replace("_", " ")
    ql = q.lower()
    words = re.findall(r"[a-z]+", ql)
    wset = set(words)
    has = lambda F: bool(wset & set(F))
    out = dict(intent=None, store=None, metric=None, date=None, date_start=None, date_end=None, is_range=False,
               product=None, weather=False, confidence=1.0, missing=[], unresolved_store=False, unresolved_date=False,
               ambiguous=None, rank_word=None, context_update=None, clarify=False, store_conf=1.0, stores_named=[])

    def done(intent):
        out["intent"] = intent
        return out

    # (1) override / prohibited action
    imp = re.match(r"^(?:[^,]{1,40},\s*)?(?:(?:please|kindly)\s+)?(?:(?:can|could|will|would)\s+you\s+|go\s+ahead\s+and\s+)?"
                   r"(?:(?:please|kindly)\s+)?(?:re)?order\b(.*)$", ql.strip())
    imperative = False
    if imp:
        nxt = re.match(r"\s*([a-z]+)", imp.group(1))
        imperative = not (nxt and nxt.group(1) in forms(["threshold", "level", "point"]))
    if has(OVERRIDE) or re.search(r"\bplace\s+an?\s+orders?\b", ql) or imperative:
        return done("out_of_scope")
    # (2) unsupported field
    if has(UNSUPPORTED) or re.search(r"\bper\s+(?:footfall|visitor)s?\b", ql):
        return done("unsupported_metric")
    # (3) diagnostic
    if has(DIAGNOSTIC):
        return done("diagnostic")

    product, qm = find_product(q)
    metrics = sorted({METRIC_WORDS[w] for w in words if w in METRIC_WORDS})
    weather = has(WEATHER_W)
    dates = parse_dates(qm)

    # ---- store resolution ----
    resolved = []                     # (store, score)
    for m in re.finditer(r"\b(" + "|".join(EXACT) + r")\b", qm, re.I):
        resolved.append((EXACT[m.group(1).lower()], 1.0))
    toks = _tokens(qm)
    cands = []
    for i, (tok, pos) in enumerate(toks):
        poss = tok.endswith("'s")
        base = tok[:-2] if poss else tok
        lb = base.lower()
        if lb in EXACT:
            continue
        prev = toks[i - 1][0].lower().replace("'s", "") if i > 0 else ""
        if lb in BRANDS:
            if poss or prev in {"for", "about", "in", "at"}:
                cands.append((base, poss, prev, True))
            continue
        if len(base) < 5 or not (base[0].isupper() or poss):
            continue
        if i == 0 and not poss:
            continue
        if lb in KEYWORDS or lb in STOP or lb.rstrip("s") in KEYWORDS:
            continue
        cands.append((base, poss, prev, False))
    unresolved_cands = []
    for base, poss, prev, brand in cands:
        if brand:
            unresolved_cands.append((base, poss, prev, True))
            continue
        score = max(difflib.SequenceMatcher(None, base.lower(), s.lower()).ratio() for s in STORES)
        if score >= THRESHOLD:
            best = max(STORES, key=lambda s: difflib.SequenceMatcher(None, base.lower(), s.lower()).ratio())
            resolved.append((best, score))
        else:
            unresolved_cands.append((base, poss, prev, False))
    no_store = not resolved
    for base, poss, prev, brand in unresolved_cands:
        if brand:
            if no_store and (poss or prev in {"for", "about", "in", "at"}):
                out["unresolved_store"] = True
        else:
            a = poss or prev in {"and", "or", "vs", "versus", "than", "for"}
            b = no_store and (prev in {"about", "in", "at"} or metrics or weather or dates["mentioned"])
            if a or b:
                out["unresolved_store"] = True
    distinct = sorted({s for s, _ in resolved}, key=[s for s, _ in resolved].index)
    names_store = bool(resolved) or out["unresolved_store"]
    names_date = dates["mentioned"]

    # (4)-(11) intent
    if product or has(INVENTORY_W):
        intent = "inventory"
    elif has(FEEDBACK_W) or re.search(r"\bcustomers?\s+(?:saying|say|says)\b", ql):
        intent = "feedback"
    elif has(TARGET_W) and (wset & TARGET_VERBS or re.search(r"\bfalls?\s+short\b", ql)) \
            or "achievement" in wset or re.search(r"\bperformance\s+bands?\b", ql):
        intent = "target_vs_actual"
    elif wset & COMPARE_W and not names_store:
        intent = "comparison"
    elif metrics:
        intent = "lookup"
    elif weather:
        intent = "weather"
    elif names_store or names_date:
        intent = "target_vs_actual" if ctx.get("last_target") else "lookup"
    else:
        return done("out_of_scope")
    out["intent"] = intent
    out["weather"] = weather
    if intent == "comparison":
        pos = [(ql.find(w), w) for w in ("highest", "lowest", "best", "worst") if w in wset]
        out["rank_word"] = min(pos)[1] if pos else None

    # ---- entities per intent ----
    conf, missing = [], []
    uses_store = intent in ("lookup", "target_vs_actual", "inventory", "feedback", "weather")
    uses_metric = intent in ("lookup", "comparison")
    uses_date = intent in ("lookup", "target_vs_actual", "comparison", "weather")
    single_date = intent in ("target_vs_actual", "weather")
    newctx = dict(ctx)
    store = metric = None
    date = None   # (start, end, is_range)

    if uses_store:
        out["stores_named"] = distinct
        if out["unresolved_store"]:
            conf.append(0.4)
        elif len(distinct) > 1:
            out["ambiguous"] = ("store", distinct)
            conf.append(0.4)
        elif distinct:
            store = distinct[0]
            conf.append(min(sc for s, sc in resolved))
            out["store_conf"] = conf[-1]
        elif intent != "inventory":
            if ctx.get("store"):
                store = ctx["store"]
            else:
                missing.append("store")
                conf.append(0.4)
    if uses_metric:
        if len(metrics) > 1:
            out["ambiguous"] = out["ambiguous"] or ("metric", metrics)
            conf.append(0.4)
        elif metrics:
            metric = metrics[0]
        elif ctx.get("metric"):
            metric = ctx["metric"]
        else:
            missing.append("metric")
            conf.append(0.4)
    if uses_date:
        if dates["status"] == "unresolved":
            out["unresolved_date"] = True
            conf.append(0.4)
        elif dates["status"] == "valid":
            if single_date and dates["is_range"]:
                out["unresolved_date"] = True
                conf.append(0.4)
            else:
                date = (dates["start"], dates["end"], dates["is_range"])
        elif ctx.get("date"):
            cd = ctx["date"]
            if single_date and cd["is_range"]:
                out["unresolved_date"] = True
                conf.append(0.4)
            else:
                date = (cd["start"], cd["end"], cd["is_range"])
        else:
            missing.append("date")
            conf.append(0.4)
    if intent == "inventory":
        if product:
            out["product"] = product
        elif ctx.get("product"):
            product = out["product"] = ctx["product"]
        else:
            missing.append("product")
            conf.append(0.4)
    out.update(store=store, metric=metric, missing=missing)
    if intent == "target_vs_actual":
        out["metric"] = None
    if date:
        out["date_start"], out["date_end"], out["is_range"] = date
        out["date"] = date[0] if not date[2] else None
    out["confidence"] = round(min(conf) if conf else 1.0, 4)
    out["clarify"] = bool(missing or out["unresolved_store"] or out["unresolved_date"] or out["ambiguous"]
                          or out["confidence"] < THRESHOLD)

    # ---- context update (used entities that resolved) ----
    if store and not out["ambiguous"]:
        newctx["store"] = store
    if metric and intent != "target_vs_actual" and not (out["ambiguous"] and out["ambiguous"][0] == "metric"):
        newctx["metric"] = metric
    if date:
        newctx["date"] = dict(start=date[0], end=date[1], is_range=date[2])
    if out["product"]:
        newctx["product"] = out["product"]
    newctx["last_target"] = intent == "target_vs_actual"
    out["context_update"] = newctx
    return out
