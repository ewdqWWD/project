"""Fixed answer templates. Every number comes from fetched data, tool results or quoted constants."""
import re

STORES = ["Mumbai", "Pune", "Hyderabad", "Bengaluru", "Ahmedabad"]
LABEL = {"revenue_inr": "revenue", "daily_target_inr": "daily target", "footfall": "footfall",
         "stockout_hours": "stockout hours", "discount_pct": "discount"}
MONEY = {"revenue_inr", "daily_target_inr"}
ALERT_THRESHOLD = "75.00"
PRODUCT_RX = re.compile(r"(Amul Milk 1L|Toor Dal 1kg|Basmati Rice 5kg|Sunflower Oil 1L|Iodised Salt 1kg|"
                        r"Instant Noodles 70g|Glucose Biscuits 200g|Detergent Powder 1kg)")
FIELD_LIST = ("revenue, daily target, footfall, stockout hours, discount, achievement, performance band, "
              "stock units, reorder threshold, rating and theme")


def d2(x):
    from agent.fetch import d2 as _d2
    return _d2(x)


def fmt(metric, s):
    if metric in MONEY:
        return f"INR {s}"
    if metric == "discount_pct":
        return f"{s}%"
    return s


def count_ungrounded(text, grounded):
    t = PRODUCT_RX.sub(" ", text)
    t = re.sub(r"\d{4}-\d{2}-\d{2}", " ", t)
    return sum(1 for n in re.findall(r"\d+(?:\.\d+)?", t) if n not in set(grounded))


def weather_sentence(store, date, w):
    vals = [f"{float(w['temperature_c']):.1f}", f"{float(w['humidity_pct']):.1f}",
            f"{float(w['wind_kmh']):.1f}", f"{float(w['rain_mm']):.1f}"]
    text = (f"Weather in {store} on {date}: temperature {vals[0]} \u00b0C, humidity {vals[1]}%, "
            f"wind {vals[2]} km/h, rain {vals[3]} mm.")
    return text, vals


def weather_evidence(store, date):
    return {"source": "weather_tool", "fields": ["temperature_c", "humidity_pct", "wind_kmh", "rain_mm"],
            "store": store, "date": date}


def clarification(u):
    parts = []
    if u["unresolved_store"]:
        parts.append("Which store do you mean? I cover " + ", ".join(STORES[:-1]) + " and " + STORES[-1] + ".")
    if u["ambiguous"]:
        kind, opts = u["ambiguous"]
        names = [o.replace("_inr", "").replace("_hours", "").replace("daily_target", "target").replace("_pct", "") for o in opts]
        parts.append(f"I found two different {kind}s ({' and '.join(names)}). Which one do you mean?")
    if u["unresolved_date"]:
        single = u["intent"] in ("target_vs_actual", "weather")
        parts.append("I could not resolve the date. Please give " + ("one date" if single else "one date or a range") +
                     " as YYYY-MM-DD or D Month YYYY" + ("" if single else ", for example between YYYY-MM-DD and YYYY-MM-DD") +
                     ", or say yesterday.")
    if u["missing"]:
        need = [{"store": "the store", "metric": "the metric", "date": "the date", "product": "the product"}[m]
                for m in u["missing"]]
        parts.append("I need " + " and ".join(need) + " to answer; please provide " +
                     ("it." if len(need) == 1 else "them."))
        if "store" in u["missing"]:
            parts.append("Which store do you mean? I cover " + ", ".join(STORES[:-1]) + " and " + STORES[-1] + ".")
    if not parts:
        parts.append("I am not sure what you mean; could you rephrase?")
    return " ".join(parts)


def compose(u, data, weather=None):
    """Returns (text, grounded_values, evidence) for a successful data fetch."""
    intent, store, metric = u["intent"], u["store"], u["metric"]
    s, e = u["date_start"], u["date_end"]
    g, ev, text = [], [], ""
    if intent == "lookup":
        val = data["value"]
        sv = d2(val) if data["kind"] == "value" else val
        g.append(sv)
        if data["kind"] == "value":
            text = f"{store}'s {LABEL[metric]} on {s} was {fmt(metric, sv)}."
            ev.append({"source": "store_daily", "fields": [metric], "store": store, "date": s})
        else:
            text = f"{store}'s average {LABEL[metric]} between {s} and {e} was {fmt(metric, sv)}."
            ev.append({"source": "store_daily", "fields": [metric], "store": store, "date": s if s == e else f"{s} to {e}"})
    elif intent == "target_vs_actual":
        v = data["value"]
        rev, tgt, ach = d2(v["revenue_inr"]), d2(v["daily_target_inr"]), d2(v["achievement_pct"])
        g += [rev, tgt, ach]
        body = (f"{store} on {s}: revenue INR {rev} against target INR {tgt}, achievement {ach}%, "
                f"band {v['performance_band']}.")
        if v["performance_band"] == "Poor":
            g.append(ALERT_THRESHOLD)
            text = (f"Draft held for human approval (alert: below the {ALERT_THRESHOLD}% achievement threshold). " + body)
        else:
            text = body
        ev.append({"source": "store_daily", "fields": ["revenue_inr", "daily_target_inr", "achievement_pct",
                                                        "performance_band"], "store": store, "date": s})
    elif intent == "comparison":
        items = data["value"]
        g += [v for _, v in items]
        order = "lowest first" if data["ascending"] else "highest first"
        when = f"on {s}" if s == e else f"between {s} and {e}"
        text = (f"Average {LABEL[metric]} per store {when}, ranked {order}: " +
                "; ".join(f"{st} {fmt(metric, v)}" for st, v in items) + f". Top of this ranking: {items[0][0]}.")
        ev.append({"source": "store_daily", "fields": [metric], "store": "all", "date": s if s == e else f"{s} to {e}"})
    elif intent == "inventory":
        rows, p = data["value"], u["product"]
        if not rows:
            text = f"No store is below its reorder threshold for {p}."
        else:
            parts = []
            for st, units, thr in rows:
                g += [str(units), str(thr)]
                parts.append(f"{st} {units} units against threshold {thr}")
            text = f"Stores below the reorder threshold for {p}: " + "; ".join(parts) + "."
        ev.append({"source": "inventory", "fields": ["stock_units", "reorder_threshold"],
                   "store": store or "all", "date": None})
    elif intent == "feedback":
        v = data["value"]
        g += [v["avg"], str(v["rated"]), str(v["total"])] if v["avg"] else [str(v["rated"]), str(v["total"])]
        avg = f"average rating {v['avg']}" if v["avg"] else "no rated responses"
        text = (f"{store} feedback: {avg} ({v['rated']} rated of {v['total']}); most frequent theme {v['theme']}.")
        ev.append({"source": "feedback", "fields": ["rating", "theme"], "store": store, "date": None})
    if weather is not None and intent in ("lookup", "target_vs_actual"):
        wt, wv = weather_sentence(store, s, weather)
        text += " " + wt
        g += wv
        ev.append(weather_evidence(store, s))
    return text, g, ev
