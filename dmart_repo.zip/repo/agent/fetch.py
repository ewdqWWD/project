"""Approved-field validation, SQLite/Python data access, retries. Values always go in as ? parameters."""
import os
import sqlite3
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_START, DATA_END = "2026-04-01", "2026-06-29"
APPROVED = {"revenue_inr": "store_daily", "daily_target_inr": "store_daily", "footfall": "store_daily",
            "stockout_hours": "store_daily", "discount_pct": "store_daily", "achievement_pct": "store_daily",
            "performance_band": "store_daily", "stock_units": "inventory", "reorder_threshold": "inventory",
            "rating": "feedback", "theme": "feedback"}
KEYS = {"store", "store_id", "date", "product", "product_id"}   # labels / filters / group keys only
TABLES = {"store_daily", "inventory", "feedback"}
_DF = _CON = None


class Unapproved(Exception):
    pass


class Escalate(Exception):
    def __init__(self, attempts):
        self.attempts = attempts


def check_field(col, table):
    """Measured value columns must be one of the 11 approved fields, in the right table."""
    if table not in TABLES or APPROVED.get(col) != table:
        raise Unapproved(f"{table}.{col} is not an approved reportable field")
    return col


def _init():
    global _DF, _CON
    if _CON is None:
        _DF = pd.read_csv(ROOT / "data" / "store_daily_clean.csv")
        inv = pd.read_csv(ROOT / "data" / "inventory.csv")
        fb = pd.read_csv(ROOT / "data" / "feedback.csv")
        _CON = sqlite3.connect(":memory:", check_same_thread=False)
        _DF.to_sql("store_daily", _CON, index=False)
        inv.to_sql("inventory", _CON, index=False)
        fb.to_sql("feedback", _CON, index=False)
    return _DF, _CON


def d2(x):
    return str(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def avg_cents(count, cents):
    """Exact mean from integer-cent sum, half-up to 2 decimals."""
    return str((Decimal(cents) / Decimal(count) / Decimal(100)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def out_of_range(start, end):
    return start < DATA_START or end > DATA_END or start > DATA_END or end < DATA_START


def with_retries(fn):
    """Max 3 attempts per query. SIMULATE_DB_FAILURES=n fails the first n attempts."""
    n = int(os.environ.get("SIMULATE_DB_FAILURES", "0") or 0)
    for attempt in range(1, 4):
        try:
            if attempt <= n:
                raise RuntimeError("simulated database failure")
            return fn(), attempt
        except Unapproved:
            raise
        except Exception:
            continue
    raise Escalate(3)


def lookup_value(store, field, date):
    """Python function: one value for one store and one date."""
    check_field(field, "store_daily")
    df, _ = _init()
    row = df[(df["store"] == store) & (df["date"] == date)]
    return None if row.empty else row.iloc[0][field]


def target_row(store, date):
    for f in ("revenue_inr", "daily_target_inr", "achievement_pct", "performance_band"):
        check_field(f, "store_daily")
    df, _ = _init()
    row = df[(df["store"] == store) & (df["date"] == date)]
    return None if row.empty else {f: row.iloc[0][f] for f in
                                   ("revenue_inr", "daily_target_inr", "achievement_pct", "performance_band")}


def fetch(u):
    """Run the data query for an understood, validated question. Returns a dict."""
    _, con = _init()
    intent, store, metric = u["intent"], u["store"], u["metric"]
    s, e = u["date_start"], u["date_end"]
    try:
        if intent == "lookup" and not u["is_range"]:
            val, att = with_retries(lambda: lookup_value(store, metric, s))
            return dict(route="python", executed=f"lookup_value({store!r}, {metric!r}, {s!r})", attempts=att,
                        kind="value", value=val, no_record=val is None)
        if intent == "target_vs_actual":
            val, att = with_retries(lambda: target_row(store, s))
            return dict(route="python", executed=f"target_row({store!r}, {s!r})", attempts=att,
                        kind="target", value=val, no_record=val is None)
        if intent == "lookup":
            col = check_field(metric, "store_daily")
            sql = (f"SELECT COUNT({col}), SUM(CAST(ROUND({col} * 100) AS INTEGER)) FROM store_daily "
                   "WHERE store = ? AND date BETWEEN ? AND ?")
            (cnt, cents), att = with_retries(lambda: con.execute(sql, (store, s, e)).fetchone())
            return dict(route="sql", executed=sql, attempts=att, kind="avg",
                        value=None if not cnt else avg_cents(cnt, cents), no_record=not cnt)
        if intent == "comparison":
            col = check_field(metric, "store_daily")
            sql = (f"SELECT store, COUNT({col}), SUM(CAST(ROUND({col} * 100) AS INTEGER)) FROM store_daily "
                   "WHERE date BETWEEN ? AND ? GROUP BY store")
            rows, att = with_retries(lambda: con.execute(sql, (s, e)).fetchall())
            vals = [(st, avg_cents(c, cs)) for st, c, cs in rows if c]
            asc = u["rank_word"] == "lowest" or (u["rank_word"] == "best" and metric == "stockout_hours") \
                or (u["rank_word"] == "worst" and metric != "stockout_hours")
            vals.sort(key=lambda x: (Decimal(x[1]) * (1 if asc else -1), x[0]))
            return dict(route="sql", executed=sql, attempts=att, kind="ranking", value=vals,
                        ascending=asc, no_record=not vals)
        if intent == "inventory":
            check_field("stock_units", "inventory"); check_field("reorder_threshold", "inventory")
            sql = ("SELECT store, stock_units, reorder_threshold FROM inventory WHERE product = ? "
                   "AND stock_units < reorder_threshold" + (" AND store = ?" if store else "") + " ORDER BY store ASC")
            cnt_sql = "SELECT COUNT(*) FROM inventory WHERE product = ?" + (" AND store = ?" if store else "")
            args = (u["product"],) + ((store,) if store else ())

            def run():
                return con.execute(cnt_sql, args).fetchone()[0], con.execute(sql, args).fetchall()
            (total, rows), att = with_retries(run)
            return dict(route="sql", executed=sql, attempts=att, kind="inventory", value=rows, no_record=total == 0)
        if intent == "feedback":
            check_field("rating", "feedback"); check_field("theme", "feedback")
            q1 = ("SELECT COUNT(rating), SUM(CAST(ROUND(rating * 100) AS INTEGER)), COUNT(*) FROM feedback WHERE store = ?")
            q2 = ("SELECT theme, COUNT(*) AS c FROM feedback WHERE store = ? GROUP BY theme ORDER BY c DESC, theme ASC LIMIT 1")

            def run():
                return con.execute(q1, (store,)).fetchone(), con.execute(q2, (store,)).fetchone()
            ((rated, cents, total), top), att = with_retries(run)
            return dict(route="sql", executed=q1 + "; " + q2, attempts=att, kind="feedback", no_record=not total,
                        value=None if not total else dict(avg=avg_cents(rated, cents) if rated else None,
                                                          rated=rated, total=total, theme=top[0]))
    except Escalate as ex:
        route = "python" if (intent == "target_vs_actual" or (intent == "lookup" and not u["is_range"])) else "sql"
        return dict(route=route, executed=None, attempts=ex.attempts, kind="escalated", value=None, escalated=True)
    except Unapproved as ex:
        return dict(route="none", executed=None, attempts=0, kind="unapproved", value=None, unapproved=str(ex))
    raise ValueError(f"no data route for intent {intent}")
