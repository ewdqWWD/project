"""handle(question, session_id, user_id): the whole pipeline + one audit log line per call."""
import json
import os
import sys
import time
import uuid
import datetime as dt
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from agent.understand import understand, DATA_START, DATA_END   # noqa: E402
from agent import fetch as F                                    # noqa: E402
from agent import answer as A                                   # noqa: E402
from tools.weather import get_weather                           # noqa: E402

SESSIONS = {}
DATE_INTENTS = ("lookup", "target_vs_actual", "comparison", "weather")


def _reply(status, text, grounded=None, evidence=None, route="none", executed=None, attempts=0, tools=None, calls=0):
    return dict(status=status, answer_text=text, grounded_values=grounded or [], evidence=evidence or [],
                route=route, executed=executed, attempts=attempts, tools_called=tools or [], tool_calls=calls)


def _process(u):
    intent = u["intent"]
    if intent == "unsupported_metric":
        return _reply("Safe Failure", "That field is not one of the approved reportable fields, so it is not available. "
                      "I can report: " + A.FIELD_LIST + ".")
    if intent == "out_of_scope":
        return _reply("Escalated", "That request is out of scope for this assistant, so I have escalated it. "
                      "I only answer questions about store revenue, targets, inventory, feedback and weather, "
                      "and I cannot send messages, place orders or change rules.")
    if intent == "diagnostic":
        return _reply("Escalated", "Why and trend questions need an analyst, so I have escalated this. "
                      "I report fetched values only and do not state causes.")
    if u["clarify"]:
        return _reply("Clarification Needed", A.clarification(u))
    if intent in DATE_INTENTS and F.out_of_range(u["date_start"], u["date_end"]):
        return _reply("Safe Failure", f"That date is outside the available data. Data is available from {DATA_START} to {DATA_END}.")
    if intent == "weather":
        w = get_weather(u["store"], u["date_start"])
        ex = f"weather_tool.get_weather({u['store']!r}, {u['date_start']!r})"
        if not w["ok"]:
            return _reply("Safe Failure", "No weather record could be found for that store and date.",
                          route="weather", executed=ex, tools=["weather_tool"], calls=1)
        text, vals = A.weather_sentence(u["store"], u["date_start"], w)
        return _reply("Answered", text, vals, [A.weather_evidence(u["store"], u["date_start"])], "weather", ex,
                      0, ["weather_tool"], 1)
    data = F.fetch(u)
    if data.get("unapproved"):
        return _reply("Safe Failure", "That field is not one of the approved reportable fields, so it is not available.")
    base = dict(route=data["route"], executed=data["executed"], attempts=data["attempts"], calls=1)
    if data.get("escalated"):
        return _reply("Escalated", "The data query failed after three attempts, so I have escalated this to a human.", **base)
    if data["no_record"]:
        return _reply("Safe Failure", "No record was found for that request.", **base)
    weather, tools = None, []
    single = intent in ("lookup", "target_vs_actual") and not u["is_range"]
    if u["weather"] and single:
        weather = get_weather(u["store"], u["date_start"])
        tools, base["calls"] = ["weather_tool"], 2
        base["route"] = "python+weather"
        base["executed"] += f"; weather_tool.get_weather({u['store']!r}, {u['date_start']!r})"
        if not weather["ok"]:
            weather = None
    text, g, ev = A.compose(u, data, weather)
    status = "Drafted" if intent == "target_vs_actual" and data["value"]["performance_band"] == "Poor" else "Answered"
    return _reply(status, text, g, ev, tools=tools, **base)


def handle(question, session_id, user_id="u1"):
    t0 = time.perf_counter()
    u = understand(question, SESSIONS.get(session_id, {}))
    r = _process(u)
    if u["context_update"] is not None:
        SESSIONS[session_id] = u["context_update"]
    r["ungrounded_numbers"] = A.count_ungrounded(r["answer_text"], r["grounded_values"])
    tokens = len(question.split()) + len(r["answer_text"].split())
    rec = dict(run_id=str(uuid.uuid4()), user_id=user_id, session_id=session_id,
               timestamp=dt.datetime.now(dt.timezone.utc).isoformat(), question=question, intent=u["intent"],
               confidence=u["confidence"], route=r["route"], executed=r["executed"], attempts=r["attempts"],
               tools_called=r["tools_called"], status=r["status"], answer_text=r["answer_text"],
               evidence=r["evidence"], grounded_values=r["grounded_values"],
               latency_ms=round((time.perf_counter() - t0) * 1000, 3), tokens_est=tokens,
               tool_calls=r["tool_calls"], ungrounded_numbers=r["ungrounded_numbers"], budget_exceeded=tokens > 150)
    path = os.environ.get("AGENT_LOG_PATH", "logs/runs.jsonl")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec
