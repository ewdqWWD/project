# Acceptance transcript (20 cases)

## A01
- session: s1
- question: What was Pune's revenue on 15 May 2026?
- simulated failures: 0
- status: Answered
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Pune's revenue on 2026-05-15 was INR 623845.00.

## A02
- session: s1
- question: And the target?
- simulated failures: 0
- status: Answered
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Pune's daily target on 2026-05-15 was INR 900000.00.

## A03
- session: s1
- question: How about Mumbai?
- simulated failures: 0
- status: Answered
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Mumbai's daily target on 2026-05-15 was INR 1050000.00.

## A04
- session: s2
- question: How is Hyderabad doing?
- simulated failures: 0
- status: Clarification Needed
- intent: lookup
- confidence: 0.4
- route: none
- attempts: 0
- answer_text: I need the metric and the date to answer; please provide them.

## A05
- session: s2
- question: revenue on 2026-05-15
- simulated failures: 0
- status: Answered
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Hyderabad's revenue on 2026-05-15 was INR 786399.27.

## A06
- session: s3
- question: What was Hydrabad's turnover yesterday?
- simulated failures: 0
- status: Answered
- intent: lookup
- confidence: 0.9412
- route: python
- attempts: 1
- answer_text: Hyderabad's revenue on 2026-06-29 was INR 784954.90.

## A07
- session: s4
- question: Did Pune hit its target on 2026-05-16?
- simulated failures: 0
- status: Drafted
- intent: target_vs_actual
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Draft held for human approval (alert: below the 75.00% achievement threshold). Pune on 2026-05-16: revenue INR 671332.65 against target INR 900000.00, achievement 74.59%, band Poor.

## A08
- session: s4
- question: Did Pune hit its target on 2026-05-20?
- simulated failures: 0
- status: Answered
- intent: target_vs_actual
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Pune on 2026-05-20: revenue INR 677739.77 against target INR 900000.00, achievement 75.30%, band Good.

## A09
- session: s4
- question: Did Mumbai hit its target on 2026-05-21?
- simulated failures: 0
- status: Answered
- intent: target_vs_actual
- confidence: 1.0
- route: python
- attempts: 1
- answer_text: Mumbai on 2026-05-21: revenue INR 1133910.49 against target INR 1050000.00, achievement 107.99%, band Excellent.

## A10
- session: s5
- question: Which store had the highest average revenue between 2026-05-01 and 2026-05-31?
- simulated failures: 0
- status: Answered
- intent: comparison
- confidence: 1.0
- route: sql
- attempts: 1
- answer_text: Average revenue per store between 2026-05-01 and 2026-05-31, ranked highest first: Mumbai INR 1071614.03; Bengaluru INR 916766.02; Hyderabad INR 900317.89; Ahmedabad INR 798849.31; Pune INR 643251.34. Top of this ranking: Mumbai.

## A11
- session: s5
- question: Which store had the lowest revenue on 2026-06-10?
- simulated failures: 0
- status: Answered
- intent: comparison
- confidence: 1.0
- route: sql
- attempts: 1
- answer_text: Average revenue per store on 2026-06-10, ranked lowest first: Pune INR 602942.85; Hyderabad INR 807522.21; Ahmedabad INR 819290.32; Bengaluru INR 848248.05; Mumbai INR 903822.34. Top of this ranking: Pune.

## A12
- session: s6
- question: Which stores are below the reorder threshold for Amul Milk?
- simulated failures: 0
- status: Answered
- intent: inventory
- confidence: 1.0
- route: sql
- attempts: 1
- answer_text: Stores below the reorder threshold for Amul Milk 1L: Hyderabad 40 units against threshold 100; Pune 85 units against threshold 100.

## A13
- session: s6
- question: What are customers saying about Hyderabad?
- simulated failures: 0
- status: Answered
- intent: feedback
- confidence: 1.0
- route: sql
- attempts: 1
- answer_text: Hyderabad feedback: average rating 2.63 (38 rated of 40); most frequent theme Stock availability.

## A14
- session: s7
- question: What was Pune's profit margin on 2026-05-15?
- simulated failures: 0
- status: Safe Failure
- intent: unsupported_metric
- confidence: 1.0
- route: none
- attempts: 0
- answer_text: That field is not one of the approved reportable fields, so it is not available. I can report: revenue, daily target, footfall, stockout hours, discount, achievement, performance band, stock units, reorder threshold, rating and theme.

## A15
- session: s8
- question: What is the capital of India?
- simulated failures: 0
- status: Escalated
- intent: out_of_scope
- confidence: 1.0
- route: none
- attempts: 0
- answer_text: That request is out of scope for this assistant, so I have escalated it. I only answer questions about store revenue, targets, inventory, feedback and weather, and I cannot send messages, place orders or change rules.

## A16
- session: s9
- question: What was Mumbai's revenue on 2026-07-15?
- simulated failures: 0
- status: Safe Failure
- intent: lookup
- confidence: 1.0
- route: none
- attempts: 0
- answer_text: That date is outside the available data. Data is available from 2026-04-01 to 2026-06-29.

## A17
- session: s10
- question: Why is Pune's revenue so low?
- simulated failures: 0
- status: Escalated
- intent: diagnostic
- confidence: 1.0
- route: none
- attempts: 0
- answer_text: Why and trend questions need an analyst, so I have escalated this. I report fetched values only and do not state causes.

## A18
- session: s11
- question: What was Kolkata's revenue on 2026-05-15?
- simulated failures: 0
- status: Clarification Needed
- intent: lookup
- confidence: 0.4
- route: none
- attempts: 0
- answer_text: Which store do you mean? I cover Mumbai, Pune, Hyderabad, Bengaluru and Ahmedabad.

## A19
- session: s12
- question: What was Pune's revenue on 15 May 2026?
- simulated failures: 2
- status: Answered
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 3
- answer_text: Pune's revenue on 2026-05-15 was INR 623845.00.

## A20
- session: s13
- question: What was Pune's revenue on 15 May 2026?
- simulated failures: 3
- status: Escalated
- intent: lookup
- confidence: 1.0
- route: python
- attempts: 3
- answer_text: The data query failed after three attempts, so I have escalated this to a human.
