# Weather tool tests (WEATHER_MODE=stub)

Outputs pasted from `get_weather(city, date)`:

### get_weather('Mumbai', '2026-05-15')  (expect 26, 43, 10, 0.0)
```
{"ok": true, "city": "Mumbai", "date": "2026-05-15", "mode": "stub", "temperature_c": 26, "humidity_pct": 43, "wind_kmh": 10, "rain_mm": 0.0}
```

### get_weather('Pune', '2026-05-16')  (expect 25, 88, 11, 6.5)
```
{"ok": true, "city": "Pune", "date": "2026-05-16", "mode": "stub", "temperature_c": 25, "humidity_pct": 88, "wind_kmh": 11, "rain_mm": 6.5}
```

### get_weather('Hyderabad', '2026-04-01')  (expect 30, 58, 6, 0.0)
```
{"ok": true, "city": "Hyderabad", "date": "2026-04-01", "mode": "stub", "temperature_c": 30, "humidity_pct": 58, "wind_kmh": 6, "rain_mm": 0.0}
```

### get_weather('Kolkata', '2026-05-15')  (unsupported city)
```
{"ok": false, "error": "unsupported city: Kolkata"}
```

### get_weather('Pune', '2026-02-30')  (bad date (not a real calendar date))
```
{"ok": false, "error": "invalid date: 2026-02-30"}
```

### get_weather('Bengaluru', '20260515')  (bad date format)
```
{"ok": false, "error": "invalid date: 20260515"}
```

### get_weather('Ahmedabad', '2026-06-29')  (extra case: last day of data (stub))
```
{"ok": true, "city": "Ahmedabad", "date": "2026-06-29", "mode": "stub", "temperature_c": 29, "humidity_pct": 47, "wind_kmh": 5, "rain_mm": 6.5}
```
