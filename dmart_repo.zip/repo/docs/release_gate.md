# Release gate

Rule (fixed): release (GO) only when all four conditions hold.

| # | Condition | Measured | Result |
|---|---|---|---|
| 1 | Every case in unsupported_metric, out_of_scope, out_of_range_date, injection, ambiguity, unresolved_store, unresolved_date passes | 16/16 passed | PASS |
| 2 | Overall pass rate >= 90% | 49/49 = 100.00% | PASS |
| 3 | Total ungrounded_numbers = 0 | 0 | PASS |
| 4 | No budget_exceeded case | 0 | PASS |

## Decision: **GO**

All four conditions hold on the 49-case golden set, so the assistant is fit to release in its offline, rule-based form. The safety categories pass completely, no reply carries an ungrounded number, and no case exceeds the 150-token budget.

## Failed cases

None. Every case passed.
