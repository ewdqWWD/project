# Data context

All data is synthetic practice data from scripts/generate_data.py (seed 2604). The raw files are never edited.

## store_daily (raw: data/store_daily.csv; cleaned: data/store_daily_clean.csv)

- **Columns (raw, 9):** date (text, ISO), store_id (text), store (text), footfall (float, 4 blanks), revenue_inr (float), daily_target_inr (int), marketing_spend_inr (int), stockout_hours (float), discount_pct (float).
- **Cleaned file adds 6 columns:** revenue_per_footfall, marketing_efficiency, achievement_pct, shortfall_inr (floats, 2 decimals), weekend_flag, performance_band (text).
- **Rows:** raw 453, cleaned **450** (5 stores x 90 days).
- **Date range:** 2026-04-01 to 2026-06-29.
- **Data-quality facts from Part A:** 3 exact duplicate rows removed; 1 negative footfall (-150, Hyderabad 2026-04-21) set to missing; 2 extreme footfalls (9800 Ahmedabad, 6100 Mumbai) capped at the per-store IQR upper bound (2281.38 and 2986.00); 5 footfall values imputed with the store median (4 originally blank plus the negative one). The cleaned file guarantees exactly 450 rows, no missing value in any column and no negative footfall. Revenue and all non-footfall columns are untouched.
- **Supports:** revenue, target, footfall, stockout hours and discount for one store and date, averages over a date range, store rankings, achievement against target and performance band.

## inventory (data/inventory.csv)

- **Columns:** store_id, store, product_id, product (text); stock_units, reorder_threshold (int).
- **Rows:** **40** (5 stores x 8 products). **Date range:** none; inventory.csv has no date column, it is a single snapshot.
- **Quality:** no missing values; Amul Milk 1L is fixed at threshold 100 (Mumbai 240, Pune 85, Hyderabad 40, Bengaluru 130, Ahmedabad 100 units). Ahmedabad is at, not below, its threshold.
- **Supports:** which stores are strictly below the reorder threshold for a product.

## feedback (data/feedback.csv)

- **Columns:** feedback_id, store_id, store (text); date (text, ISO); rating (int, 1-5); theme (text).
- **Rows:** **200** (40 per store). **Date range:** 2026-04-01 to 2026-06-29.
- **Quality:** 12 rows have no rating. They stay missing and are never replaced by an average; averages use the rated rows only.
- **Supports:** average rating over rated rows, counts of rated and all rows, most frequent theme for a store.

## Relationships

The three datasets join on the **store name** (store_id S01-S05 is equivalent). inventory and feedback do not need a date for the agent's answers, so a date in such a question is dropped.
